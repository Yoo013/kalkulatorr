package com.example.kalkulator

import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.HorizontalScrollView
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import java.util.function.UnaryOperator

class KalkulatorActivity : AppCompatActivity() {

    private lateinit var tvDisplay: TextView

    private var angkaPertama = ""
    private var angkaKedua = ""
    private var operator = ""
    private var displayInput = ""


    private var currentInput = "0"
    private var firstValue = 0.0
    private var isNewOperation = true

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_kalkulator)

        // Display
        tvDisplay = findViewById(R.id.tvDisplay)


        val btn0 = findViewById<Button>(R.id.btn0)
        val btn1 = findViewById<Button>(R.id.btn1)
        val btn2 = findViewById<Button>(R.id.btn2)
        val btn3 = findViewById<Button>(R.id.btn3)
        val btn4 = findViewById<Button>(R.id.btn4)
        val btn5 = findViewById<Button>(R.id.btn5)
        val btn6 = findViewById<Button>(R.id.btn6)
        val btn7 = findViewById<Button>(R.id.btn7)
        val btn8 = findViewById<Button>(R.id.btn8)
        val btn9 = findViewById<Button>(R.id.btn9)


        val btnTambah = findViewById<Button>(R.id.btnPlus)
        val btnHapus = findViewById<Button>(R.id.btnBackspace)
        val btnKurang = findViewById<Button>(R.id.btnMinus)
        val btnMultiply = findViewById<Button>(R.id.btnMultiply)
        val btnBagi = findViewById<Button>(R.id.btnDivide)

        val btnSamaDengan = findViewById<Button>(R.id.btnEquals)
        val btnClose = findViewById<Button>(R.id.btnClose)


        btn0.setOnClickListener{
            inputAngka(angka = "0")
        }

        btn1.setOnClickListener{
            inputAngka(angka = "1")
        }

        btn2.setOnClickListener{
            inputAngka(angka = "2")
        }
        btn3.setOnClickListener{
            inputAngka(angka = "3")
        }

        btn4.setOnClickListener{
            inputAngka(angka = "4")
        }

        btn5.setOnClickListener{
            inputAngka(angka = "5")
        }
        btn6.setOnClickListener{
            inputAngka(angka = "6")
        }
        btn7.setOnClickListener{
            inputAngka(angka = "7")
        }
        btn8.setOnClickListener{
            inputAngka(angka = "8")
        }
        btn9.setOnClickListener{
            inputAngka(angka = "9")
        }
        

        btnTambah.setOnClickListener { inputOperator(op = "+") }
        btnKurang.setOnClickListener { inputOperator(op = "-") }
        btnMultiply.setOnClickListener { inputOperator(op = "x") }
        btnBagi.setO
    }



    private fun inputAngka(angka: String){
        if (operator.isEmpty()){
            angkaPertama += angka
        } else {
            angkaKedua += angka
        }
        displayInput += angka
        tvDisplay.text = displayInput
    }

    private fun inputOperator(op: String) {
        if(angkaPertama.isNotEmpty() && operator.isEmpty()){
            operator = op
            displayInput += op
            tvDisplay.text = displayInput
        }
    }
}